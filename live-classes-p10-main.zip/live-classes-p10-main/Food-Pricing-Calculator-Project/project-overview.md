---
sidebar_position: 1
---

# Project Overview

Project is having the following components.

1. Frontend for Web 
2. Backend for API
3. Database 