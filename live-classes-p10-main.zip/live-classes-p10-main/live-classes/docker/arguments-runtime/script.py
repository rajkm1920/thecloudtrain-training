import sys

if __name__ == "__main__":
    print(f"Arguments passed: {sys.argv[1:]}")
